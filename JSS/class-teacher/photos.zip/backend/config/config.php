<?php
use Medoo\Medoo;

return[
  'database' => [
  'type' => 'mysql',
  'host' => 'localhost',
  'database' => 'jss',
  'username' => 'root',
  'password' => '',
  'charset' => 'utf8mb4'
  ],
];