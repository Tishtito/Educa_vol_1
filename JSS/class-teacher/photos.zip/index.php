<?php
// Redirect to pages folder
header("location: pages/");
exit;
?>
