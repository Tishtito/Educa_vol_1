<?php
use Medoo\Medoo;

return[
  'database' => [
  'type' => 'mysql',
  'host' => 'localhost',
  'database' => 'lower_classes',
  'username' => 'root',
  'password' => '',
  'charset' => 'utf8mb4'
  ],
];