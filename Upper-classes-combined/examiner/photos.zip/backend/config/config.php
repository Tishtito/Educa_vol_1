<?php
use Medoo\Medoo;

return[
  'database' => [
  'type' => 'mysql',
  'host' => 'localhost',
  'database' => 'upper_classes1',
  'username' => 'root',
  'password' => '',
  'charset' => 'utf8mb4'
  ],
];