<?php
//Redirect to pages folder
header('Location: Pages/dashboard/index.html');
exit;   
?>